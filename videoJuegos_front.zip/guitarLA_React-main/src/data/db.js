export const db = [
    {
        id: 1,
        name: 'Halo 1',
        image: 'juego2',
        description: 'Morbi ornare augue nisl, vel elementum dui mollis vel. Curabitur non ex id eros fermentum hendrerit.',
        price: 299,
    },
    {
        id: 2,
        name: 'Halo 2',
        image: 'juego1',
        description: 'Morbi ornare augue nisl, vel elementum dui mollis vel. Curabitur non ex id eros fermentum hendrerit.',
        price: 349,
    },
    {
        id: 3,
        name: 'Halo 3',
        image: 'juego3',
        description: 'Morbi ornare augue nisl, vel elementum dui mollis vel. Curabitur non ex id eros fermentum hendrerit.',
        price: 329,
    },
    {
        id: 4,
        name: 'Halo 3: ODST',
        image: 'juego4',
        description: 'Morbi ornare augue nisl, vel elementum dui mollis vel. Curabitur non ex id eros fermentum hendrerit.',
        price: 299,
    },
    {
        id: 5,
        name: 'Halo 4',
        image: 'juego5',
        description: 'Morbi ornare augue nisl, vel elementum dui mollis vel. Curabitur non ex id eros fermentum hendrerit.',
        price: 399,
    },
  ]